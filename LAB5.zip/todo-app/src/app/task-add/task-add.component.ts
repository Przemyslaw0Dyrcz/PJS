import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TaskService } from '../task.service';
import { Task } from '../task.model';

@Component({
  selector: 'app-task-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Dodaj zadanie</h2>
    <form (ngSubmit)="onSubmit()">
      <label for="title">Tytuł:</label>
      <input id="title" [(ngModel)]="task.title" name="title" required />

      <label for="description">Opis:</label>
      <textarea id="description" [(ngModel)]="task.description" name="description"></textarea>

      <button type="submit">Dodaj</button>
    </form>
  `,
})
export class TaskAddComponent {
  task: Task = { id: 0, title: '', description: '', completed: false };

  constructor(private taskService: TaskService, private router: Router) {}

  onSubmit(): void {
    this.taskService.addTask(this.task).subscribe(() => {
      this.router.navigate(['/']);
    });
  }
}
