import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { TaskService } from '../task.service';
import { Task } from '../task.model';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <h2>Lista zadań</h2>
    <ul>
      <li *ngFor="let task of tasks">
        <a [routerLink]="['/edit', task.id]">{{ task.title }}</a>
      </li>
    </ul>
    <button routerLink="/add">Dodaj zadanie</button>
  `,
})
export class TaskListComponent implements OnInit {
  tasks: Task[] = [];

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {
    this.taskService.getTasks().subscribe((tasks) => (this.tasks = tasks));
  }
}
