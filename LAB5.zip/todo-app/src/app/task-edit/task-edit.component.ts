import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskService } from '../task.service';
import { Task } from '../task.model';

@Component({
  selector: 'app-task-edit',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <h2>Edytuj zadanie</h2>
    <form (ngSubmit)="onSubmit()">
      <label for="title">Tytuł:</label>
      <input id="title" [(ngModel)]="task.title" name="title" required />

      <label for="description">Opis:</label>
      <textarea
        id="description"
        [(ngModel)]="task.description"
        name="description"
      ></textarea>

      <label for="completed">Ukończone:</label>
      <input
        id="completed"
        type="checkbox"
        [(ngModel)]="task.completed"
        name="completed"
      />

      <button type="submit">Zapisz</button>
    </form>
  `,
})
export class TaskEditComponent implements OnInit {
  task: Task = { id: 0, title: '', description: '', completed: false }; // Initialize here

  constructor(
    private route: ActivatedRoute,
    private taskService: TaskService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.taskService.getTask(id).subscribe((task) => {
      if (task) {
        this.task = task; // Override defaults
      } else {
        this.router.navigate(['/']); // Handle invalid ID
      }
    });
  }

  onSubmit(): void {
    if (this.task) {
      this.taskService.updateTask(this.task).subscribe(() => {
        this.router.navigate(['/']);
      });
    }
  }
}