const express = require('express');
const url = require('url');
const router = express.Router();

const PagesController = require('../controllers/PagesController');
const ApplicationsController = require('../controllers/ApplicationsController');
const Zadanie2 = require('../Controllers/Zadanie2');
//zadanie1
router.get('/nowy', (req, res) => {
    const parsedUrl = url.parse(req.url);
    parsedUrl.pathname = '/serwer1';

    const newUrl = url.format(parsedUrl);

    res.redirect(newUrl);
});

router.get('/', PagesController.home);
router.post('/applications', ApplicationsController.store);
router.get('/witaj', Zadanie2.hello);
module.exports = router;
