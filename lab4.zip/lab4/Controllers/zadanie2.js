const querystring = require('querystring');

exports.hello = (req, res) => {
    const queryParameters = req.url.split('?')[1];
    const params = querystring.parse(queryParameters);

    const firstName = params['imie'];
    const lastName = params['nazwisko'];

    res.send('witaj ' + firstName + ' ' + lastName);
}
