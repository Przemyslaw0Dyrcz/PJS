const http = require('http');
const url = 'http://www.Bing.com';

http.get(url, (response) => {
    let data = '';

    response.on('data', (chunk) => {
        data += chunk;
    });

    response.on('end', () => {
        console.log(data);
    });
}).on('error', (error) => {
    console.error(`Wystąpił błąd: ${error.message}`);
});
