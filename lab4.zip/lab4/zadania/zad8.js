const net = require("net");

// client
const client = net.createConnection({
    port: 8080,
});

client.on("connect", () => {
    client.write("Witaj, serwerze!");
});

client.on("data", (data) => {
    console.log(data);
    client.destroy();
});

client.on("end", () => {
    console.log("Połączenie zakończone.");
});

// server
const server = net.createServer((socket) => {
    console.log("Nowe połączenie z klientem.");

    socket.on("data", (data) => {
        console.log("Odebrano wiadomość od klienta:", data);
        socket.write("Witaj, kliencie!");
    });

    socket.on("end", () => {
        console.log("Połączenie z klientem zakończone.");
    });
});

server.listen(8080);
