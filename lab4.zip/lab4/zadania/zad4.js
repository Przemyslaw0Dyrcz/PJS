const http = require('http');

const port = 3000;

const server = http.createServer((req, res) => {
    const path = req.url;
    res.writeHead(200, {'Content-Type': 'text/plain'});

    switch (path) {
        case '/nowa':
            res.write('To jest nowa strona!');
            break;
        case '/stara':
            res.write('To jest stara strona...');
            break;
        default:
            res.write('Witaj! Użyj /nowa lub /stara');
            break;
    }

    res.end();
});

server.listen(port, () => {
    console.log(`Listening on:${port}`);
});
