let licznik: number = 0;
const zwieksz = () => { licznik =licznik+1;}
console.log(licznik);
zwieksz();
console.log(licznik);