const suma = (...arg: number[]) => {
  let suma = 0;
  for (let i = 0; i < arg.length; i++) {
    suma += arg[i];
  }
  return suma;
}
console.log(suma(1,1,1,1,1,1,1,1,1,1));
console.log(suma(4,5));
console.log(suma(12,8,9));