/**
 * @param {number} czasOczekiwania - czas w milisekundach
 * @param {string} opis - wiadomość do wyświetlenia
 * @returns {Promise<boolean>}
 */
const poczekaj = (czasOczekiwania: number, opis: string): Promise<boolean> => {
  return new Promise((rozwiąż) => {
    setTimeout(() => {
      console.log(opis);
      rozwiąż(true);
    }, czasOczekiwania);
  });
};

const uruchomAsynchronicznie = async () => {
  console.log('Start funkcji asynchronicznej...');

  await poczekaj(1000, "Oczekiwanie 1...");
  await poczekaj(1000, "Oczekiwanie 2...");
  await poczekaj(1000, "Oczekiwanie 3...");

  console.log('Koniec działania funkcji asynchronicznej...');
};

uruchomAsynchronicznie();
