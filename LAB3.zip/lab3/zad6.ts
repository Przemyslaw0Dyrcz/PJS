class Car {
  public marka: string;
  public rocznik: number;

  constructor(marka: string, rocznik: number) {
    this.marka = marka;
    this.rocznik = rocznik;
  }

  public wyswietlInfo(): void {
    console.log(`Samochód: ${this.marka}, Rocznik: ${this.rocznik}`);
  }
}

const Merc = new Car('Mercedes', 2020);
const Toyota = new Car('Toyota', 2015);
const BMW = new Car('BMW', 2018);

Merc.wyswietlInfo();
Toyota.wyswietlInfo();
BMW.wyswietlInfo(); 
