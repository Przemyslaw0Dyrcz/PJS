export class Car {
    public marka: string;
    public rocznik: number;
  
    constructor(marka: string, rocznik: number) {
      this.marka = marka;
      this.rocznik = rocznik;
    }
  
    public wyswietlInfo(): void {
      console.log(`Samochód: ${this.marka}, Rocznik: ${this.rocznik}`);
    }
  }