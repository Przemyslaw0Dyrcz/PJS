"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Car = void 0;
class Car {
    constructor(marka, rocznik) {
        this.marka = marka;
        this.rocznik = rocznik;
    }
    wyswietlInfo() {
        console.log(`Samochód: ${this.marka}, Rocznik: ${this.rocznik}`);
    }
}
exports.Car = Car;
