import { Car } from './zad8car';
import { Truck } from './zad8truck';

// Tworzenie obiektów klasy Car
const osobowy = new Car('Toyota', 2015);
osobowy.wyswietlInfo(); // Samochód: Toyota, Rocznik: 2015

// Tworzenie obiektów klasy Truck
const tir = new Truck('Volvo', 2022, 18);
tir.wyswietlInfo(); // Ciężarówka: Volvo, Rocznik: 2022, Ładowność: 18 ton

