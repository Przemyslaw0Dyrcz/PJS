import { Car } from './zad8car';
export class Truck extends Car {
    public ladownosc: number; 
  
    constructor(marka: string, rocznik: number, ladownosc: number) {
      super(marka, rocznik); 
      this.ladownosc = ladownosc;
    }
  
    public wyswietlInfo(): void {
      console.log(
        `Ciężarówka: ${this.marka}, Rocznik: ${this.rocznik}, Ładowność: ${this.ladownosc} ton`
      );
    }
  }