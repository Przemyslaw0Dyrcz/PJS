"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Truck = void 0;
const zad8car_1 = require("./zad8car");
class Truck extends zad8car_1.Car {
    constructor(marka, rocznik, ladownosc) {
        super(marka, rocznik);
        this.ladownosc = ladownosc;
    }
    wyswietlInfo() {
        console.log(`Ciężarówka: ${this.marka}, Rocznik: ${this.rocznik}, Ładowność: ${this.ladownosc} ton`);
    }
}
exports.Truck = Truck;
