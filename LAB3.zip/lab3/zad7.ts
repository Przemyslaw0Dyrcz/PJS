class Car {
  public marka: string;
  public rocznik: number;

  constructor(marka: string, rocznik: number) {
    this.marka = marka;
    this.rocznik = rocznik;
  }

  public wyswietlInfo(): void {
    console.log(`Samochód: ${this.marka}, Rocznik: ${this.rocznik}`);
  }
}

class Truck extends Car {
  public ladownosc: number; 

  constructor(marka: string, rocznik: number, ladownosc: number) {
    super(marka, rocznik); 
    this.ladownosc = ladownosc;
  }

  public wyswietlInfo(): void {
    console.log(
      `Ciężarówka: ${this.marka}, Rocznik: ${this.rocznik}, Ładowność: ${this.ladownosc} ton`
    );
  }
}

const scania = new Truck('Scania', 2022, 18);
const volvo = new Truck('Volvo', 2020, 3);

scania.wyswietlInfo(); 
volvo.wyswietlInfo(); 

