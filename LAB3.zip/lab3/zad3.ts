var q: string = '1';
var w: number = 2;
var e: boolean = false;
var r: number[] = [1,2,3];
var t: Array<number> = [1,2,3];
var y: [number, string] = [1, 'cos'];
var u: any = 1;
var i: any = '2';
var o: any = false;
var p: null = null;
var a: undefined = undefined;
var s: object = {};


