enum Plec {
  Mezczyzna,
  Kobieta,
  Inna
}
interface Osoba {
  imie: string;
  nazwisko: string;
  plec: Plec;
}
const wyswietlOsobe = (osoba: Osoba) => {
  let oznaczeniePlec = 'Inna';

  if (osoba.plec === Plec.Kobieta) {
    oznaczeniePlec = 'Kobieta';
  } else if (osoba.plec === Plec.Mezczyzna) {
    oznaczeniePlec = 'Mężczyzna';
  }
  console.table([
    {etykieta: 'Imię', wartosc: osoba.imie},
    {etykieta: 'Nazwisko', wartosc: osoba.nazwisko},
    {etykieta: 'Płeć', wartosc: oznaczeniePlec},
  ]);
}
const przykladOsoby: Osoba = {
  imie: 'Anna',
  nazwisko: 'Nowak',
  plec: Plec.Kobieta
}

wyswietlOsobe(przykladOsoby);

