class Car {
  public marka: string;
  public rocznik: number; 
}

const Merc = new Car();
Merc.marka = 'Mercedes';
Merc.rocznik = 2020; 

const Toyota = new Car();
Toyota.marka = 'Toyota';
Toyota.rocznik = 2015; 

const BMW = new Car();
BMW.marka = 'BMW';
BMW.rocznik = 2018; 

console.log(Merc, Toyota, BMW);
