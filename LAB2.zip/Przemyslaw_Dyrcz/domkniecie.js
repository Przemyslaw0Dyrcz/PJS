function displayList(list) {
    list.forEach(item => {
        process.nextTick(() => {
            console.log(item);
        });
    });
}

let list = ['Item 1', 'Item 2', 'Item 3'];
displayList(list);


function displayArray(arr, index = 0) {
    if (index < arr.length) {
        console.log(arr[index]);
        process.nextTick(() => {
            displayArray(arr, index + 1);
        });
    }
}

let array = [1, 2, 3, 4, 5];
displayArray(array);
