const http = require('http');

const server = http.createServer((req, res) => {
    console.log('Otrzymano żądanie:', req.url);
    res.end('Zdarzenie otrzymane!');
});

server.listen(3000, () => {
    console.log('Serwer działa na porcie 3000');
});

const EventEmitter = require('events');

class User extends EventEmitter {
    constructor(name) {
        super();
        this._name = name;
    }

    set name(newName) {
        this._name = newName;
        this.emit('nameChanged', newName);
    }

    get name() {
        return this._name;
    }
}

const user = new User('Jan');
user.on('nameChanged', (newName) => {
    console.log(`Imię zostało zmienione na: ${newName}`);
});

user.name = 'Anna';  // Wywołanie zdarzenia
