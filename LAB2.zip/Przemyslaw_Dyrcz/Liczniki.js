let startTime = Date.now();

setInterval(() => {
    let elapsedTime = Math.floor((Date.now() - startTime) / 1000);
    console.log(`Czas, który upłynął: ${elapsedTime} sekund`);
}, 1000);
setInterval(() => {
    let counter = 0;
    let intervalId = setInterval(() => {
        if (counter < 5) {
            console.log('a');
            counter++;
        } else {
            clearInterval(intervalId);
        }
    }, 10);
}, 1000);
const alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('');
const vowels = ['a', 'e', 'i', 'o', 'u'];

let index = 0;
function displayLetters() {
    if (index < alphabet.length) {
        let letter = alphabet[index];
        console.log(letter);
        index++;
        if (vowels.includes(letter)) {
            setTimeout(displayLetters, 2000);  // Przerwa 2 sekundy dla samogłosek
        } else {
            setTimeout(displayLetters, 500);  // Przerwa 0.5 sekundy dla innych liter
        }
    }
}

displayLetters();
